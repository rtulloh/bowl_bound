"""Bowl Bound: a Python implementation of the Bowl Bound college-football board game.

The engine in this package is the authoritative source for all football decisions.
Front ends display engine-provided state and outcomes; they never reimplement rules.
"""

__version__ = "1.1.2"
DISPLAY_VERSION = "1.1.2"

__all__ = ["__version__"]
