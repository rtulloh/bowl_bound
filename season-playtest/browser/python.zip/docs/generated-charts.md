# Generated teams

The v1.1.2 catalog adds [55 generated 2002 teams](#generated-2002-cohort) and
eight generated 1972 Big Eight teams, with reviewed commentary rosters, for
**181 playable teams** across the three seasons and original fictional samples.
The published 2007 chart files are unchanged.

## Published 2007 cohort

Alpha 6 adds **116 generated 2007 college teams** alongside the original fictional
Cedar Valley and Harbor Tech samples, for **118 playable teams**. Three source
teams remain unavailable because their generation evidence did not pass the
cohort's coverage gates. No rejected teams were added to increase the count.

Choose a team from the web setup menu. From an installed source checkout, for
example:

```sh
python -m bowl_bound --play -d hard --away 2007/ohio-state --home 2007/lsu --compact --trace 2>&1 | tee /tmp/bb.log
```

The generated 2007 teams have no historical player rosters; commentary uses generic
player roles. The two fictional samples retain their original fictional names.
Save/resume requires the same team-chart content; keep copies of saves before
upgrading or replacing a chart.

## Generation and attribution

These charts are independent statistical estimates built from individual
ESPN-derived 2007 play-by-play events supplied through SportsDataverse/cfbfastR.
The [SportsDataverse data release store](https://github.com/sportsdataverse/sportsdataverse-data)
declares [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Credit
SportsDataverse, cfbfastR and the ESPN-source lineage. The generated resources
carry [their attribution and license](../seasons/GENERATED-LICENSE.md).

The generator classifies event outcomes, uses disclosed pooling/inference where
called play families or defensive formations are unobserved, and quantizes
distributions into Bowl Bound dice/chart cells. Proprietary benchmark chart values
do not construct or select this cohort. The charts are modified statistical
estimates, not official Bowl Bound charts or reproductions of source narratives.

Version 1.0.0 retains the experimental `authored-bb-budget-aware-v1` defensive
policy and its existing per-call INC/INT/QT and per-formation INT budgets.
Full plays consult both offense and Priority; zero modeled mechanisms remain
dormant. Tactical formation roles remain authored assumptions.

After calibration, `authored-bb-call-depth-v1` assigns passing interception
catch depths separately for Screen, Sprint Out, Boot-leg and Drop Back, on both
offense and defense. This corrects assigning a pooled unidentified long-pass
interception to Screen solely because its depth appears in the source.
All 116 teams lack qualifying observations that identify both the designed
passing call and its catch depth. Their conditional shapes therefore use
declared authored priors, rather than claimed historical call-specific evidence.
Missing locations and unidentified calls stay unknown.

The update changes 789 INT catch-depth values while preserving the INT slots
and frequencies, priorities, flags and other football facts. Supplemental,
special-teams, PAT and recovery semantics are unchanged. The independent gate
checks exact finite depth allocation as well as the preserved event budgets.

The release pins exactly 464 chart files and 116 virtual-cell provenance CSVs in
[the exact release manifest](../release/manifest.json). Each generated team has one
derived virtual source describing its emitted cell tokens, colors and coordinates.
This is generated evidence, not original PDF geometry or raw play-by-play. Detailed
source ancestry remains private. The supplied source snapshot SHA-256 remains
`1f8e553002c0299a2993eb533231053d6cf406dbe0e9d41ecc400267484bb1ba`.
The parent budget exporter is `bb-chartgen-budget-alpha-v1`; its model SHA-256 is
`a46aaf838a718e012a2ce90a4438e6de475a0d810f18ab7e92d87148603a9e5f`.
The added conditional-depth policy SHA-256 is
`f44fbd9822fa844155a94905aca30ff5c30a2ace52b62e4c2086178cacb224a1`.
Alpha 8's numeric formation prior remains part of this experimental lineage.
The [OOB evidence correction](dev-notes/college-chart-oob-evidence-audit.md) fixes
a positive-only denominator that had marked nearly every ordinary numeric cell.
OOB allocation now uses positive narrative mentions over matching numeric-outcome
support, with exact dice quantization. Missing mentions remain unknown: these are
lower-bound narrative-incidence estimates, not fully observed historical OOB rates.
Some columns have no positive evidence and remain explicitly unidentified; an
unmarked cell does not establish that the source play was observed in bounds.

The 2007 selection distributes no raw play-by-play, source narratives, private
imported benchmark charts, historical rosters, logos, saves or detailed audits.
Generated 2007 Ohio State and Miami charts are distinct from privately imported
2002 charts, which remain excluded.

## Testing limits and feedback

The generated charts remain community-testing estimates, not a claim of historical calibration.
Provider-to-normalized event checks do not independently reconcile official
season box-score totals or establish complete historical coverage. Ambiguous
provider records remain tracked source limitations; unknown kick distances are
excluded from numerical fitting rather than converted to zero. Older
retained season audits reconciled games under frozen baseline coaching; their
results do not establish accuracy under the current release AI. Matching a mean
or completing a season does not establish every team's balance. Sparse families,
unobserved formations, finite chart cells, uncertain tails and missing source
fixtures remain limitations. The retained Alpha 8 diagnostic below found material
rushing, sack, interception and fumble gaps. Those historical results are not fresh
measurements of 1.0.0. Bounded current-engine game checks establish mechanical
consistency and supplies descriptive results; it does not certify historical fit
or prove improvement. The metadata power rating is a uniform placeholder, not a
historical ranking. Recent seasons are separate future work.

Please report the version, matchup, difficulty, seed/save when available, and the
decision or result that seems wrong. Scores, rushing/passing balance, turnovers,
special teams and repeated computer choices are useful observations. Follow the
[reporting guide](reporting-bugs.md), and review attachments before sending them.
No affiliation or endorsement by the data providers, universities or game
publisher is implied. The code license does not grant rights to excluded content.

Generated-chart releases now require an [automated probability and tactical
audit](generated-chart-audits.md), alongside separate source qualification and
current-engine game/coaching reviews. The gate evaluates actual chart behavior;
different-looking cells and successful completed games alone are insufficient.

## Retained Alpha 8 source-fit diagnostic

The following historical Alpha 8 diagnostic describes 116 paired games per chart
version using then-current Hard-v15 against baseline-v15 coaching, with the same
opponents and seeds between versions. Each generated team has two team-game
exposures. The conditioned supplied source covers 1,291 team-games for these 116
subjects with unequal exposure and different historical opponents/calls. This is
retained evidence, not an Alpha 9 measurement or historical-accuracy pass.

| Measurement | Conditioned supplied source | Neutral predecessor | Corrected catalog |
| --- | ---: | ---: | ---: |
| Completion / pass attempt | 58.79% | 58.84% | 58.50% |
| Interception / pass attempt | 3.22% | 4.35% | 3.97% |
| Sack / dropback | 5.75% | 7.18% | 7.19% |
| Pure rushing yards / attempt | 4.773 | 3.838 | 3.791 |
| Passing yards / attempt | 6.873 | 6.439 | 6.404 |
| Primary fumble / known eligible snap | 1.483% | 2.211% | 2.214% |
| Points / team-game | 28.024 | 28.392 | 28.862 |

Sacks count as NCAA rushing attempts in Bowl Bound. Pure rushing removes sacks
and restores their lost yardage; sack rate uses pass attempts plus sacks. Source
pass exposure is 43,217 attempts, versus 8,362 neutral and 8,419 corrected. Known
primary-fumble source exposure is 92,427 snaps with one additional unidentified
snap; the simulations contain 17,958 and 17,973 eligible snaps. Return-holder
fumbles are separate from primary fumbles. Points use consistent supplied-provider
final-score headers including returns and overtime, not reconstructed touchdown
counts. Official source completeness and totals remain unverified.

Per-team mean absolute errors, neutral to corrected, are completion 5.31→5.16
percentage points, interception 2.01→1.99 points, sack 2.49→2.42 points, pure
rushing 0.923→0.995 yards/attempt, passing 0.971→0.918 yards/attempt, primary
fumbles 1.193→1.155 percentage points and scoring 7.59→7.02 points/team-game.
Individual two-game estimates vary widely; these averages do not establish every
team's balance or justify tuning parameters to this corpus.

The old experimental pure-rushing error bound of 0.5 yards/attempt is exceeded.
That remains a failed accuracy assessment, alongside the material sack,
interception and fumble gaps above. Earlier research already retained neutral
profiles after proposed refinements failed protected per-team safeguards; its
older coaching evidence does not certify the current policy. No accuracy failure
is relabeled a pass because structural or bookkeeping checks succeed.

A bounded mechanism review replayed retained production traces and evaluated
11,296 observed ordinary call contexts with exact 216×36 primary dice. Under the
same corrected call mixture, the direct authored prior changes conditional
numeric run/pass means by about −0.010/+0.013 yards. Those conditional means
exclude pending branches and are not source yards per attempt. Known numeric
credit matches engine field clipping exactly; clipping removes about 0.201 yards
per pure rush attempt and 0.532 per pass attempt in the corrected corpus. It
does not explain the full remaining source-fit gap. Fixed plays, supplements,
fumbles, chart quantization and AI/schedule mixtures remain model limitations
for further work. No new rule, observer or selector defect was reproduced by
this bounded review, and no source or coefficient was changed to clear it.

## Generated 2002 cohort

The owner approves the selected 55-team statistical cohort and reviewed
commentary rosters for tracking and upstream publication on 2026-11-17.
The exact release manifest adds 275 generated chart/provenance files and 110
roster/source-note files. The combined catalog has 179 generated teams across
1972, 2002 and 2007 plus the two original fictional samples, for 181 playable
teams. This is a selected
cohort, not the whole 2002 college schedule. A fresh checkout discovers all
three seasons normally.

For example, from a source checkout:

```sh
python -m bowl_bound --play -d hard --away 2002/ohio-state --home 2002/miami --compact --trace
```

The 2002 inputs are a separately retained ESPN core API snapshot, supplemented
by 99 reviewed official-gamebook factual corrections. Credit ESPN and the
identified official statistical sources; each roster's source notes identify
its own sources. These inputs are separate from the 2007 SportsDataverse data
release. The [scoped output notice](../seasons/GENERATED-LICENSE.md) covers only
the project's original contributions; it asserts no upstream license grant or
clearance of source-access terms. No source expression, downloaded pages/PDFs,
private imported charts, logos, photos, saves or detailed audits are included.

Generation uses the authored `bb-chartgen-cohort-v1` model, the existing
conditional interception-depth policy and a shared offensive
`run_yards_scale=1.15`. All other offensive fields and all defensive profiles
remain neutral. This parameter conditions the generated chart before finite
quantization; it does not multiply engine outcomes. Engine rules, coaching,
source observations and statistical targets remain unchanged.

The first eligible setting was frozen before comparison on unused simulation
seeds. Both the original and selected panels cover the same 251 fixtures.
Against source non-sack rushing 4.502 yards/attempt, the selected panel reaches
4.238 versus 3.498 for neutral charts. All 12 existing pooled reference checks
pass. Average absolute team rushing error improves from 0.936 to 0.293;
47/55 teams are within half a yard. The paired improvement is 0.740
yards/attempt, with approximate 95% interval [0.616, 0.864]. These intervals
describe simulation variation, not source uncertainty. Numerical tuning stops
at this first validated setting.

Historical fit remains UNVERIFIED. Eight individual teams remain outside the
half-yard reference, and unused simulation seeds are not held-out historical
data. Fumble denominators include disclosed modeled absence assumptions;
260 recovery associations remain unresolved under the clock fallback.
Gross-kick and blocked-punt locations are sparse, OOB observations are unknown,
and designed calls/formation interactions use authored priors. The roster lists
can be partial, spring, depth or bowl selections; missing positions retain
generic commentary. Names do not affect game outcomes or gameplay randomness.
Report these experimental teams through the ordinary feedback process above.
