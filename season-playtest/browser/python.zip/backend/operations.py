"""Framework-independent operations for the HTTP and browser adapters."""

import json
import secrets
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path
from threading import RLock
from typing import Annotated, Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

from bowl_bound import DISPLAY_VERSION, __version__
from bowl_bound.models import TeamChart
from bowl_bound.regulation import RegulationView
from bowl_bound.resolution import ChartResolutionError
from bowl_bound.roster import RosterFormatError
from bowl_bound.rules_summary import rules_summary
from bowl_bound.save_game import (
    MAX_SAVE_BYTES,
    GameRevisionConflict,
    SavedGame,
    SaveFormatError,
    dumps_game,
    loads_game,
)
from bowl_bound.session import (
    InvalidDecisionError,
    PendingDecisionError,
    PlayReport,
    SessionFinishedError,
    SessionView,
)
from bowl_bound.team_catalog import (
    TEAM_ID_MAX_LENGTH,
    TEAM_ID_RE,
    TeamCatalog,
    TeamNotFoundError,
)
from bowl_bound.team_csv import TeamFileMetadata

from .played_season import PlayedSeason, SeasonFixture, SeasonResult, SeasonTeam
from .season_templates import list_season_templates

MAX_GAMES = 50
MAX_COMMAND_BYTES = 16 * 1024
TeamId = Annotated[str, StringConstraints(max_length=TEAM_ID_MAX_LENGTH)]
HumanSide = Literal["home", "away"]


def operation_body_limit(path: str) -> int:
    """Allow complete season ledgers and game checkpoints through either adapter."""
    if (
        path == "/api/games/load"
        or path.startswith("/api/seasons")
        or path.endswith("/season-result")
    ):
        return MAX_SAVE_BYTES
    return MAX_COMMAND_BYTES


class OperationError(Exception):
    """An operation failure safe to present to the caller."""

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


@dataclass(frozen=True)
class Operation:
    """A game operation shared by both transports."""

    method: str
    path: str
    handler: Callable[..., object]


class SeasonTeamInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: TeamId
    conference: str = Field(default="", max_length=100)


class SeasonFixtureInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    week: int = Field(ge=1, le=1000, strict=True)
    away: TeamId
    home: TeamId
    conference_game: bool = Field(default=False, strict=True)
    date: str | None = Field(default=None, max_length=10)


class NewSeason(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1, max_length=160)
    template_id: str | None = Field(default=None, max_length=40)
    teams: list[SeasonTeamInput] = Field(default_factory=list, max_length=250)
    fixtures: list[SeasonFixtureInput] = Field(default_factory=list, max_length=2000)


class SeasonSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")
    snapshot: dict[str, Any]


class SeasonResultRequest(SeasonSnapshot):
    fixture_id: str = Field(min_length=1, max_length=100)
    game_id: str = Field(min_length=1, max_length=100)


def _season_view(season: PlayedSeason) -> dict[str, object]:
    return {"snapshot": season.to_dict(), "summary": season.summary()}


class NewGame(BaseModel):
    model_config = ConfigDict(extra="forbid")
    home: TeamId
    away: TeamId
    seed: int | None = Field(default=None, ge=0, le=2**63 - 1)
    start_yards_to_goal: int = Field(default=65, ge=1, le=99)
    mode: Literal["drive", "regulation"] = "drive"
    game_type: Literal["regular", "postseason"] = "regular"
    difficulty: Literal["easy", "medium", "hard"] | None = None
    coach_policy: (
        Literal[
            "baseline",
            "baseline-v2",
            "baseline-v8",
            "baseline-v9",
            "baseline-v10",
            "baseline-v11",
            "baseline-v12",
            "baseline-v13",
            "baseline-v14",
            "baseline-v15",
            "chart-v1",
            "chart-v2",
            "easy-v1",
            "medium-v1",
            "hard-v1",
            "easy-v2",
            "medium-v2",
            "hard-v2",
            "chart-v3",
            "easy-v3",
            "medium-v3",
            "hard-v3",
            "chart-v4",
            "easy-v4",
            "medium-v4",
            "hard-v4",
            "chart-v5",
            "easy-v5",
            "medium-v5",
            "hard-v5",
            "chart-v6",
            "easy-v6",
            "medium-v6",
            "hard-v6",
            "chart-v7",
            "chart-v8",
            "chart-v9",
            "chart-v10",
            "chart-v11",
            "chart-v12",
            "chart-v13",
            "chart-v14",
            "chart-v15",
            "easy-v7",
            "medium-v7",
            "hard-v7",
            "easy-v8",
            "medium-v8",
            "hard-v8",
            "easy-v9",
            "medium-v9",
            "hard-v9",
            "easy-v10",
            "easy-v11",
            "easy-v12",
            "easy-v13",
            "easy-v14",
            "easy-v15",
            "medium-v10",
            "medium-v11",
            "medium-v12",
            "medium-v13",
            "medium-v14",
            "medium-v15",
            "hard-v10",
            "hard-v11",
            "hard-v12",
            "hard-v13",
            "hard-v14",
            "hard-v15",
        ]
        | None
    ) = None

    @model_validator(mode="after")
    def unambiguous_policy(self) -> "NewGame":
        if self.difficulty is not None and self.coach_policy is not None:
            raise ValueError("choose difficulty or legacy coach_policy, not both")
        return self


class Snap(BaseModel):
    model_config = ConfigDict(extra="forbid")
    play: str = Field(pattern=r"^(?:[1-9]|Q|RZDZ)$")
    defense: str = Field(
        pattern=r"^(?:[A-F]|RUN|PASS|NICKEL|REDZONE|WCSNEAK|WCRZDZ|WC(?:[1-4]|5(?:SOP|BLP)?|[6-9]))$"
    )


class Kick(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Literal["kickoff", "onside_kickoff", "punt", "field_goal"]


class GameAction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Literal[
        "review:continue",
        "kneel",
        "hail_mary",
        "elect_safety",
        "timeout:home",
        "timeout:away",
        "timeout_after:home",
        "timeout_after:away",
        "bounds:oob",
        "bounds:ib",
    ]


class Decision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    choice: str = Field(min_length=1, max_length=100)


class CoachStep(BaseModel):
    model_config = ConfigDict(extra="forbid")
    human_side: HumanSide
    human_call: str | None = Field(
        default=None,
        pattern=r"^(?:[1-9QA-F]|RZDZ|RUN|PASS|NICKEL|REDZONE|WCSNEAK|WCRZDZ|WC(?:[1-4]|5(?:SOP|BLP)?|[6-9]))$",
    )
    expected_revision: int = Field(ge=0, strict=True)


@dataclass(frozen=True)
class RegisteredGame:
    """In-memory game plus its immutable API control mode."""

    session: SavedGame
    human_side: HumanSide | None
    team_ids: tuple[str, str]


def _report_data(
    session: SavedGame, report: PlayReport | None, view: SessionView | RegulationView
) -> dict[str, object] | None:
    if report is None:
        return None
    return {
        **asdict(report),
        "commentary": session.commentary(report),
        "highlights": list(report.highlight_tags),
        "timing_label": view.timing_label(report.number)
        if isinstance(view, RegulationView)
        else None,
    }


def _view_data(
    session: SavedGame, view: SessionView | RegulationView, human_side: HumanSide | None = None
) -> dict[str, object]:
    data = asdict(view)
    data["log"] = [_report_data(session, report, view) for report in view.log]
    guidance = session.fourth_down_guidance(human_side, view=view)
    data["fourth_down_guidance"] = asdict(guidance) if guidance else None
    return data


def create_operations(seasons_root: Path, *, max_games: int = MAX_GAMES) -> list[Operation]:
    """Build the operations and one isolated in-memory session registry."""
    operations: list[Operation] = []

    def operation(
        method: str, path: str
    ) -> Callable[[Callable[..., object]], Callable[..., object]]:
        def register_handler(handler: Callable[..., object]) -> Callable[..., object]:
            operations.append(Operation(method, path, handler))
            return handler

        return register_handler

    games: OrderedDict[str, RegisteredGame] = OrderedDict()
    registry_lock = RLock()
    coordinator_error_detail = "Unable to prepare a legal coached turn for this game state."

    def coordinator_conflict() -> OperationError:
        return OperationError(status_code=409, detail=coordinator_error_detail)

    def lookup(game_id: str) -> RegisteredGame:
        with registry_lock:
            registered = _session(games, game_id)
            games.move_to_end(game_id)
            return registered

    def require_control(registered: RegisteredGame, human_side: HumanSide | None) -> None:
        if registered.human_side != human_side:
            raise OperationError(
                status_code=409,
                detail="Game control mode or human side does not match this request.",
            )

    @operation("GET", "/api/health")
    def health() -> dict[str, str]:
        return {"status": "healthy", "service": "bowl-bound"}

    @operation("GET", "/api/version")
    def version() -> dict[str, str]:
        return {"version": DISPLAY_VERSION, "python_version": __version__}

    @operation("GET", "/api/teams")
    def teams() -> dict[str, list[dict[str, object]]]:
        catalog = TeamCatalog(seasons_root)
        try:
            entries = catalog.teams()
        except ValueError:
            return {"teams": [], "problems": []}
        found = [{"id": entry.key, "name": entry.name, "season": entry.season} for entry in entries]
        problems = [
            {"id": problem.partition(":")[0], "reason": "could not be read"}
            for problem in catalog.problems
        ]
        return {"teams": found, "problems": problems}

    @operation("GET", "/api/seasons/templates")
    def season_templates() -> dict[str, object]:
        entries = TeamCatalog(seasons_root).teams()
        templates = list_season_templates([team.key for team in entries])
        return {
            "templates": [
                {key: template[key] for key in ("id", "name", "source_year", "coverage")}
                for template in templates
            ],
            "conferences": {
                team["team_id"]: team["conference"]
                for template in templates
                for team in template["teams"]
            },
        }

    @operation("POST", "/api/seasons")
    def new_season(body: NewSeason) -> dict[str, object]:
        catalog = {team.key: team for team in TeamCatalog(seasons_root).teams()}
        try:
            source_year = None
            selected = body.teams
            fixtures = body.fixtures
            if body.template_id is not None:
                if selected or fixtures:
                    raise ValueError(
                        "A historical schedule already defines its teams and fixtures."
                    )
                template = next(
                    (
                        item
                        for item in list_season_templates(catalog)
                        if item["id"] == body.template_id
                    ),
                    None,
                )
                if template is None:
                    raise ValueError("This historical schedule is unavailable.")
                source_year = template["source_year"]
                selected = [
                    SeasonTeamInput(id=item["team_id"], conference=item["conference"] or "")
                    for item in template["teams"]
                ]
                fixtures = [
                    SeasonFixtureInput(
                        week=item["week"],
                        away=item["away_team_id"],
                        home=item["home_team_id"],
                        conference_game=item["conference_game"],
                        date=item["date"],
                    )
                    for item in template["fixtures"]
                ]
            season = PlayedSeason(
                id=uuid4().hex,
                name=body.name.strip(),
                source_year=source_year,
                teams=tuple(
                    SeasonTeam(
                        team.id,
                        catalog[team.id].name,
                        catalog[team.id].season,
                        team.conference.strip() or None,
                    )
                    for team in selected
                ),
                fixtures=tuple(
                    SeasonFixture(id=str(index), **fixture.model_dump())
                    for index, fixture in enumerate(fixtures, start=1)
                ),
            )
        except KeyError as error:
            raise OperationError(422, "A selected team is unavailable.") from error
        except ValueError as error:
            raise OperationError(422, str(error)) from error
        return _season_view(season)

    @operation("POST", "/api/seasons/summary")
    def season_summary(body: SeasonSnapshot) -> dict[str, object]:
        try:
            return _season_view(PlayedSeason.from_dict(body.snapshot))
        except ValueError as error:
            raise OperationError(422, str(error)) from error

    @operation("GET", "/api/rules")
    def rules(season: int, game_type: str = "regular") -> dict[str, object]:
        """Summarize the engine's home-season rules without exposing chart data."""
        return asdict(rules_summary(season, game_type))

    @operation("GET", "/api/games/{game_id}/charts")
    def game_charts(game_id: str, side: HumanSide) -> dict[str, object]:
        return asdict(lookup(game_id).session.charts(side))

    @operation("POST", "/api/games")
    def new_game(body: NewGame, human_side: HumanSide | None = None) -> dict[str, object]:
        home, home_metadata = _load_with_metadata(seasons_root, body.home)
        away, away_metadata = _load_with_metadata(seasons_root, body.away)
        seed = body.seed if body.seed is not None else secrets.randbits(32)
        try:
            session = SavedGame.new(
                home,
                away,
                home_id=body.home,
                away_id=body.away,
                seed=seed,
                mode=body.mode,
                game_type=body.game_type,
                start_yards_to_goal=body.start_yards_to_goal,
                coach_policy=body.coach_policy or "baseline",
                difficulty=None if body.coach_policy else body.difficulty or "medium",
                home_privileges=home_metadata.defense_chart_markers,
                away_privileges=away_metadata.defense_chart_markers,
            )
            session.load_rosters(seasons_root)
        except ValueError as error:
            raise OperationError(status_code=422, detail=str(error)) from error
        return register(session, human_side, (body.home, body.away))

    def register(
        session: SavedGame, human_side: HumanSide | None, team_ids: tuple[str, str]
    ) -> dict[str, object]:
        game_id = secrets.token_urlsafe(9)
        registered = RegisteredGame(session, human_side, team_ids)
        with registry_lock:
            games[game_id] = registered
            while len(games) > max_games:
                games.popitem(last=False)
        return present(game_id, registered)

    def present(game_id: str, registered: RegisteredGame) -> dict[str, object]:
        session = registered.session
        coaching = {"difficulty": session.difficulty}
        if session.difficulty is None:
            coaching["coach_policy"] = session.coach_policy
        if registered.human_side is None:
            return {
                "game_id": game_id,
                "seed": session.seed,
                **coaching,
                "view": _view_data(session, session.view()),
                "revision": session.revision,
            }
        try:
            view, turn = session.coach_view(registered.human_side)
        except ValueError as error:
            raise coordinator_conflict() from error
        return {
            "game_id": game_id,
            "seed": session.seed,
            **coaching,
            "view": _view_data(session, view, registered.human_side),
            "turn": asdict(turn),
            "revision": session.revision,
        }

    def command(
        session: SavedGame, operation: str, value: str, human_side: HumanSide | None
    ) -> dict[str, object]:
        if human_side is None:
            report, view = session.execute_with_view(operation, [value])
            return {
                "report": _report_data(session, report, view),
                "view": _view_data(session, view),
                "revision": session.revision,
            }
        try:
            report, view, turn = session.coach_execute(human_side, operation, value)
        except InvalidDecisionError:
            raise
        except ValueError as error:
            raise coordinator_conflict() from error
        return {
            "report": _report_data(session, report, view),
            "view": _view_data(session, view, human_side),
            "turn": asdict(turn),
            "revision": session.revision,
        }

    @operation("GET", "/api/games/{game_id}/final-box")
    def final_box(game_id: str) -> dict[str, object]:
        session = lookup(game_id).session
        view = session.view()
        if not isinstance(view, RegulationView) or not view.finished:
            raise OperationError(409, "A season cannot record an unfinished regulation game.")
        return {
            "away_score": view.score.away,
            "home_score": view.score.home,
            "away_statistics": asdict(view.statistics.away),
            "home_statistics": asdict(view.statistics.home),
        }

    @operation("POST", "/api/games/{game_id}/season-result")
    def season_result(game_id: str, body: SeasonResultRequest) -> dict[str, object]:
        registered = lookup(game_id)
        view = registered.session.view()
        if not isinstance(view, RegulationView) or not view.finished:
            raise OperationError(409, "A season cannot record an unfinished regulation game.")
        try:
            season = PlayedSeason.from_dict(body.snapshot)
            fixture = next((item for item in season.fixtures if item.id == body.fixture_id), None)
            if fixture is None or (fixture.home, fixture.away) != registered.team_ids:
                raise ValueError("This game doesn't match the scheduled fixture.")
            season.record(
                body.fixture_id,
                SeasonResult(
                    body.game_id,
                    view.score.away,
                    view.score.home,
                    view.statistics.away,
                    view.statistics.home,
                ),
            )
        except ValueError as error:
            raise OperationError(422, str(error)) from error
        return _season_view(season)

    @operation("POST", "/api/seasons/remove-result")
    def remove_season_result(body: SeasonResultRequest) -> dict[str, object]:
        try:
            season = PlayedSeason.from_dict(body.snapshot)
            season.remove_result(body.fixture_id, body.game_id)
        except ValueError as error:
            raise OperationError(422, str(error)) from error
        return _season_view(season)

    @operation("GET", "/api/games/{game_id}/save")
    def save_game(game_id: str) -> str:
        session = lookup(game_id).session
        try:
            return dumps_game(session)
        except SaveFormatError as error:
            raise OperationError(status_code=422, detail=str(error)) from error

    @operation("POST", "/api/games/load")
    def load_game(body: bytes | str, human_side: HumanSide | None = None) -> dict[str, object]:
        try:
            text = body.decode("utf-8") if isinstance(body, bytes) else body
            session = loads_game(text, lambda key: _load_with_metadata(seasons_root, key))
            session.load_rosters(seasons_root)
        except (SaveFormatError, RosterFormatError, UnicodeError, OperationError) as error:
            raise OperationError(
                status_code=422,
                detail=(
                    "Save is invalid, incompatible, or its local teams are unavailable; "
                    "current game unchanged."
                ),
            ) from error
        teams = json.loads(text)["teams"]
        return register(session, human_side, (teams["home"]["id"], teams["away"]["id"]))

    @operation("GET", "/api/games/{game_id}")
    def get_game(game_id: str, human_side: HumanSide | None = None) -> dict[str, object]:
        registered = lookup(game_id)
        require_control(registered, human_side)
        return present(game_id, registered)

    @operation("POST", "/api/games/{game_id}/coach")
    def coach_step(game_id: str, body: CoachStep) -> dict[str, object]:
        registered = lookup(game_id)
        require_control(registered, body.human_side)
        if registered.human_side is None:
            raise OperationError(status_code=409, detail="This game uses manual controls.")
        session = registered.session
        try:
            report, view, turn = session.coach_step(
                body.human_side,
                body.human_call,
                expected_revision=body.expected_revision,
            )
        except GameRevisionConflict as error:
            raise OperationError(status_code=409, detail=str(error)) from error
        except (SessionFinishedError, PendingDecisionError) as error:
            raise OperationError(status_code=409, detail=str(error)) from error
        except InvalidDecisionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error
        except ChartResolutionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error
        except ValueError as error:
            raise coordinator_conflict() from error
        return {
            "report": _report_data(session, report, view),
            "view": _view_data(session, view, body.human_side),
            "turn": asdict(turn),
            "revision": session.revision,
        }

    @operation("POST", "/api/games/{game_id}/snap")
    def snap(game_id: str, body: Snap) -> dict[str, object]:
        registered = lookup(game_id)
        if registered.human_side is not None:
            raise OperationError(status_code=409, detail="This game uses coached controls.")
        session = registered.session
        try:
            report, view = session.execute_with_view("snap", [body.play, body.defense])
        except (SessionFinishedError, PendingDecisionError) as error:
            raise OperationError(status_code=409, detail=str(error)) from error
        except InvalidDecisionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error
        except ChartResolutionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error
        return {
            "report": _report_data(session, report, view),
            "view": _view_data(session, view),
            "revision": session.revision,
        }

    @operation("POST", "/api/games/{game_id}/kick")
    def kick(game_id: str, body: Kick, human_side: HumanSide | None = None) -> dict[str, object]:
        registered = lookup(game_id)
        require_control(registered, human_side)
        session = registered.session
        try:
            return command(session, "kick", body.action, human_side)
        except (SessionFinishedError, PendingDecisionError) as error:
            raise OperationError(status_code=409, detail=str(error)) from error
        except InvalidDecisionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error

    @operation("POST", "/api/games/{game_id}/decision")
    def decide(
        game_id: str, body: Decision, human_side: HumanSide | None = None
    ) -> dict[str, object]:
        registered = lookup(game_id)
        require_control(registered, human_side)
        session = registered.session
        try:
            return command(session, "decide", body.choice, human_side)
        except (SessionFinishedError, PendingDecisionError) as error:
            raise OperationError(status_code=409, detail=str(error)) from error
        except InvalidDecisionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error

    @operation("POST", "/api/games/{game_id}/action")
    def game_action(
        game_id: str, body: GameAction, human_side: HumanSide | None = None
    ) -> dict[str, object]:
        registered = lookup(game_id)
        require_control(registered, human_side)
        session = registered.session
        if session.mode != "regulation":
            raise OperationError(status_code=422, detail="clock actions require regulation mode")
        try:
            return command(session, "action", body.action, human_side)
        except (SessionFinishedError, PendingDecisionError) as error:
            raise OperationError(status_code=409, detail=str(error)) from error
        except InvalidDecisionError as error:
            raise OperationError(status_code=422, detail=str(error)) from error

    return operations


def _session(games: OrderedDict[str, RegisteredGame], game_id: str) -> RegisteredGame:
    registered = games.get(game_id)
    if registered is None:
        raise OperationError(status_code=404, detail="no such game")
    return registered


def _load_with_metadata(seasons_root: Path, team_id: str) -> tuple[TeamChart, TeamFileMetadata]:
    if len(team_id) > TEAM_ID_MAX_LENGTH or not TEAM_ID_RE.fullmatch(team_id):
        raise OperationError(status_code=422, detail="team id must look like 2002/ohio-state")
    try:
        return TeamCatalog(seasons_root).load_with_metadata(team_id)
    except TeamNotFoundError as error:
        raise OperationError(status_code=404, detail="no such team") from error
    except ValueError as error:
        raise OperationError(
            status_code=422, detail="that team's files could not be read"
        ) from error
